---
title: Online Portfolio — Ikechukwu [Last Name]
---

# Ikechukwu [Last Name] — Technical Writing Portfolio

Welcome! This portfolio highlights professional writing samples across **reports**, **proposals**, **instructions**, **visuals**, and **presentations**.

## About Me
- CIS student (Post University); veteran interested in reading, book projects, and soccer.

## Featured Work

### Research & Reports
- **E-waste and Its Environmental Impact (Long Report)** — [View PDF](docs/writing/e-waste-long-report.pdf)
- **The Power of Workplace Messaging** — [View PDF](docs/writing/workplace-messaging.pdf)
- **Social Media Analysis — Apple** — [View PDF](docs/writing/apple-social-media-analysis.pdf)
- **Technical Proposal (Unit 6.1)** — [View PDF](docs/writing/technical-proposal.pdf)

### Instructions & Procedures
- **Step-by-Step Instructions (Unit 5.1)** — [View PDF](docs/instructions/device-setup-instructions.pdf)
- **Removing Bias & “You Attitude”** — [View PDF](docs/writing/inclusive-language-revisions.pdf)

### Visuals
- **Orange Production Visuals (2017–2021)** — [View PDF](docs/visuals/orange-production-visuals.pdf)

### Presentations
- **E-waste and Its Environmental Impact (Slides)** — [View PPTX](presentations/e-waste-presentation.pptx)

## Contact
- Email: your.email@example.com
- LinkedIn: https://www.linkedin.com/in/your-profile
